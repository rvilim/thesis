gcoeff={}

#Hao 2011
gcoeff[("Saturn","a")]=60268.0
gcoeff[("Saturn","g",1,0)]=21191.0
gcoeff[("Saturn","g",2,0)]=1586.0
gcoeff[("Saturn","g",3,0)]=2374.0

