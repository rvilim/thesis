gcoeff={}

#Jupiter from Conerney et al
gcoeff[("Jupiter","a")]=71323.0
gcoeff[("Jupiter","g",1,0)]=424202
gcoeff[("Jupiter","g",1,1)]=-65929
gcoeff[("Jupiter","h",1,1)]=24116
gcoeff[("Jupiter","g",2,0)]=-2181
gcoeff[("Jupiter","g",2,1)]=-71106
gcoeff[("Jupiter","h",2,1)]=-40304
gcoeff[("Jupiter","g",2,2)]=48714
gcoeff[("Jupiter","h",2,2)]=7179
gcoeff[("Jupiter","g",3,0)]=7565
gcoeff[("Jupiter","g",3,1)]=-15493
gcoeff[("Jupiter","h",3,1)]=-38824
gcoeff[("Jupiter","g",3,2)]=19775
gcoeff[("Jupiter","h",3,2)]=34243
gcoeff[("Jupiter","g",3,3)]=-17958
gcoeff[("Jupiter","h",3,3)]=-22439