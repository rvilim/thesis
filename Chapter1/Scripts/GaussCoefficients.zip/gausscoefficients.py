import mercury
import earth
import jupiter
import saturn
import uranus
import neptune

gcoeff=dict(mercury.gcoeff.items()+earth.gcoeff.items()+jupiter.gcoeff.items()+saturn.gcoeff.items()+uranus.gcoeff.items()+neptune.gcoeff.items())




