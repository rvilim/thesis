gcoeff={}

#Anderson?
gcoeff[("Mercury","g",1,0)]=195.0
gcoeff[("Mercury","g",2,0)]=gcoeff[("Mercury","g",1,0)]*0.38
gcoeff[("Mercury","a")]=2440.0
